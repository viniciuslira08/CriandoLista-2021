package cursojava.executavel;
import cursojava.classes.Aluno;
import cursojava.classes.Disciplina;
import jdk.swing.interop.SwingInterOpUtils;

import javax.swing.*;

public class PrimeiraClasseJava {


    public static void main(String[] args) {



        /*=============================================*/
        Aluno aluno = new Aluno();
        Disciplina disciplina =  new Disciplina();

        String nome = JOptionPane.showInputDialog("Qual é o nome do aluno?");
        aluno.setNome(nome);

        String idade = JOptionPane.showInputDialog("Qual é a Idade?");
        aluno.setIdade(Integer.valueOf(idade));

        String dataNacimento = JOptionPane.showInputDialog
                ("Qual é a data de Nacimento");
        aluno.setDataNacimento(dataNacimento);

        for (int pos = 1 ; pos <= 4; pos++){
            String nomeDisciplina = JOptionPane.showInputDialog
                    ("Nome da displicna" +pos+"?");
            String notaDisciplina = JOptionPane.showInputDialog
                    ("Nota da displicna" +pos+"?");

            Disciplina disciplina1 = new Disciplina();
            disciplina.setNota01(nomeDisciplina);
            disciplina.setNota01(Double.valueOf(notaDisciplina));

            aluno.getDisciplina().add(disciplina);
        }

        /*=============================================*/
        /*Aluno aluno1 = new Aluno();*/
        /*=============================================*/

        System.out.println("Média da nota é: " + aluno.getMediaNota());
        System.out.println("Resultado = " + aluno.getAlunoAprovado());
        System.out.println();
        /*=============================================*/

    }
}
