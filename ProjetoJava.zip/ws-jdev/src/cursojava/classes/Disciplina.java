package cursojava.classes;

import java.util.Objects;

public class Disciplina {

    private double getNota01;
    double nota01;
    private double getNota02;
    double nota02;
    private double getNota03;
    double nota03;
    private double getNota04;
    double nota04;

    public double getGetNota01() {
        return getNota01;
    }

    public void setGetNota01(double getNota01) {
        this.getNota01 = getNota01;
    }

    public double getNota01() {
        return nota01;
    }

    public void setNota01(String nota01) {
        this.nota01 = nota01;
    }

    public double getGetNota02() {
        return getNota02;
    }

    public void setGetNota02(double getNota02) {
        this.getNota02 = getNota02;
    }

    public double getNota02() {
        return nota02;
    }

    public void setNota02(double nota02) {
        this.nota02 = nota02;
    }

    public double getGetNota03() {
        return getNota03;
    }

    public void setGetNota03(double getNota03) {
        this.getNota03 = getNota03;
    }

    public double getNota03() {
        return nota03;
    }

    public void setNota03(double nota03) {
        this.nota03 = nota03;
    }

    public double getGetNota04() {
        return getNota04;
    }

    public void setGetNota04(double getNota04) {
        this.getNota04 = getNota04;
    }

    public double getNota04() {
        return nota04;
    }

    public void setNota04(double nota04) {
        this.nota04 = nota04;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Disciplina)) return false;
        Disciplina that = (Disciplina) o;
        return Double.compare(that.getGetNota01(), getGetNota01()) == 0 && Double.compare(that.getNota01(), getNota01()) == 0 && Double.compare(that.getGetNota02(), getGetNota02()) == 0 && Double.compare(that.getNota02(), getNota02()) == 0 && Double.compare(that.getGetNota03(), getGetNota03()) == 0 && Double.compare(that.getNota03(), getNota03()) == 0 && Double.compare(that.getGetNota04(), getGetNota04()) == 0 && Double.compare(that.getNota04(), getNota04()) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getGetNota01(), getNota01(), getGetNota02(), getNota02(), getGetNota03(), getNota03(), getGetNota04(), getNota04());
    }

    public void add(Disciplina disciplina) {
    }
}
