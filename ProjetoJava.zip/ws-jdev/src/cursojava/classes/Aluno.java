package cursojava.classes;

public class Aluno {
    private String nome;
    private int idade;
    private String dataNacimento;

    private Disciplina disciplina = new Disciplina();

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    @Override
    public String toString() {
        return "Aluno{" +
                "nome='" + nome + '\'' +
                ", idade=" + idade +
                ", dataNacimento='" + dataNacimento + '\'' +
                ", disciplina=" + disciplina +
                '}';
    }

    public Aluno() {

    }

    public Aluno(String nomePadrao){
        nome = nomePadrao;
    }

    public void setDataNacimento(String dataNacimento) {
        this.dataNacimento = dataNacimento;
    }

    public Aluno (String nomePadrao, int idadePadrao){
        nome = nomePadrao;
        idade = idadePadrao;

    }

    public void setNome(String nome){
        this.nome = nome;

    }
    public String getNome(){
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getDataNacimento() {
        return dataNacimento;
    }

    /*=====================================================*/
    public double getMediaNota(){
        return (disciplina.getNota01() + disciplina.getNota02() +
                disciplina.getNota03() + disciplina.getNota04()) / 4;
    }

    public String getAlunoAprovado (){
        double media = this.getMediaNota();
        if(media >= 70){
            return "Aluno está aprovado";
        }else {
            return "Aluno reprovado";
        }
    }


}
